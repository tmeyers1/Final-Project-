Team Members Name: Matt Boccia, Greg Matzelle, Tyler Meyers and Sean Reddy 
B#'s:  B00552313, B00653165, B00642492 , B00647139, respectively. 
How to run the program: The program will automatically run once the user is prompted to press the 'Enter' button and does so. 
Requirements for the program: There are no requirements, just to have fun!
What is it/How does it work: Our program runs a Hangman Game. The game requires the user to guess letters that make up a random hidden word. 
            Each letter the user guesses correctly will reveal that letter in the hidden word. Each guess that the user 
            guesses incorrectly will be added to the already used list and a body part will be added to the Hangman. 
            Once the body of the Hangman is complete, after 10 guesses, the game will end unsuccessfully. If the user guesses 
            all correct letters and completes the hidden word within the 10 guesses, they win!
References: https://codereview.stackexchange.com/questions/171164/python-simple-hangman-game
Other Details: None 



